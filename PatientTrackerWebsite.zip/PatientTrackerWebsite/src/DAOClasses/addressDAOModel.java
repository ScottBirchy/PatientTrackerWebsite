package DAOClasses;

import Utilities.DBUtility;
import Utilities.DBUtilityConstants;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelClasses.address;

public class addressDAOModel {
    //unsure what the implements in above line does, i didnt include it
    public boolean addAddress (address address) throws SQLException {
        
        Connection conn = null;
        PreparedStatement pst = null;
        boolean addressStatus = false;
        
        try {
            conn = DBUtility.getConnection(DBUtilityConstants.DRIVER, DBUtilityConstants.URL, DBUtilityConstants.USERNAME, DBUtilityConstants.PASSWORD);
            
            if (conn != null) {
                String INSERT_NEW_ADDRESS_SQL = "INSERT INTO `patienttracker_final`.`address"
		+ " (address_id, address, city, zip, state) VALUES (?,?,?,?,?);";
                pst = conn.prepareStatement(INSERT_NEW_ADDRESS_SQL);
                
                pst.setInt(1, address.getAddress_id()); 
                pst.setString (2, address.getAddress());
                pst.setString (3, address.getCity());
                pst.setInt (4, address.getZip());
                pst.setString (5, address.getState());
                
                int numRowsAffected = pst.executeUpdate();
				
		if (numRowsAffected > 0) {
                    addressStatus = true;
            }
        }
    }
    catch (Exception ex) {
	if (conn != null) {
            try {
                
                pst.close();
                conn.close();
            }
            
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
        return addressStatus;
    }
}
