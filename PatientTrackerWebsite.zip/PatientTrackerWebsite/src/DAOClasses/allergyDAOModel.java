package DAOClasses;

import Utilities.DBUtility;
import Utilities.DBUtilityConstants;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelClasses.allergy;

public class allergyDAOModel {
    //unsure what the implements in above line does, i didnt include it
public boolean addAllergy (allergy allergy) throws SQLException {
        
        Connection conn = null;
        PreparedStatement pst = null;
        boolean allergyStatus = false;
        
        try {
            conn = DBUtility.getConnection(DBUtilityConstants.DRIVER, DBUtilityConstants.URL, DBUtilityConstants.USERNAME, DBUtilityConstants.PASSWORD);
            
            if (conn != null) {
                String INSERT_NEW_ALLERGY_SQL = "INSERT INTO `patienttracker_final`.`allergy"
		+ " (allergyid, allergyname) VALUES (?,?);";
                pst = conn.prepareStatement(INSERT_NEW_ALLERGY_SQL);
                
                pst.setInt(1, allergy.getAllergyid()); 
                pst.setString (2, allergy.getAllergyname());
                
                int numRowsAffected = pst.executeUpdate();
				
		if (numRowsAffected > 0) {
                    allergyStatus = true;
            }
        }
    }
    catch (Exception ex) {
	if (conn != null) {
            try {
                
                pst.close();
                conn.close();
            }
            
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
        return allergyStatus;
    }
}