package DAOClasses;

import modelClasses.allergy;

public class allergyDAO {
    
    boolean addAllergy (allergy allergy);
    
}
