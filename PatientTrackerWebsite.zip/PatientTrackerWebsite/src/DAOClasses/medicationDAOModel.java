package DAOClasses;

import Utilities.DBUtility;
import Utilities.DBUtilityConstants;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelClasses.medication;

public class medicationDAOModel {
    //unsure what the implements in above line does, i didnt include it
    public boolean addMedication (medication medication) throws SQLException {
        
        Connection conn = null;
        PreparedStatement pst = null;
        boolean medicationStatus = false;
        
        try {
            conn = DBUtility.getConnection(DBUtilityConstants.DRIVER, DBUtilityConstants.URL, DBUtilityConstants.USERNAME, DBUtilityConstants.PASSWORD);
            
            if (conn != null) {
                String INSERT_NEW_MEDICATION_SQL = "INSERT INTO `patienttracker_final`.`medication"
		+ " (medicationid, medicationname) VALUES (?,?);";
                pst = conn.prepareStatement(INSERT_NEW_MEDICATION_SQL);
                
                pst.setInt(1, medication.getMedicationid()); 
                pst.setString (2, medication.getMedicationname());
                
                int numRowsAffected = pst.executeUpdate();
				
		if (numRowsAffected > 0) {
                    medicationStatus = true;
            }
        }
    }
    catch (Exception ex) {
	if (conn != null) {
            try {
                
                pst.close();
                conn.close();
            }
            
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
        return medicationStatus;
    }
}
