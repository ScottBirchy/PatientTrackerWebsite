package DAOClasses;

import modelClasses.address;

public class addressDAO {
    
    boolean addAddress (address address);
    
}
