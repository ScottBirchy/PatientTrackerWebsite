package DAOClasses;

import Utilities.DBUtility;
import Utilities.DBUtilityConstants;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelClasses.patient;

public class patientDAOModel {
    //unsure what the implements in above line does, i didnt include it
    public boolean addPatient (patient patient) throws SQLException {
        
        Connection conn = null;
        PreparedStatement pst = null;
        boolean patientStatus = false;
        
        try {
            conn = DBUtility.getConnection(DBUtilityConstants.DRIVER, DBUtilityConstants.URL, DBUtilityConstants.USERNAME, DBUtilityConstants.PASSWORD);
            
            if (conn != null) {
                String INSERT_NEW_PATIENT_SQL = "INSERT INTO `patienttracker_final`.`patient"
		+ " (patientid, firstname, lastname, dob, phone, email, gender, weight, height, bloodpressure) VALUES (?,?,?,?,?,?,?,?,?,?);";
                pst = conn.prepareStatement(INSERT_NEW_PATIENT_SQL);
                
                pst.setInt(1, patient.getPatientid()); 
                pst.setString (2, patient.getFirstname());
                pst.setString (3, patient.getLastname());
                pst.setInt (4, patient.getDob());
                pst.setInt (5, patient.getPhone());
                pst.setString (6, patient.getEmail());
                pst.setString (7, patient.getGender());
                pst.setInt (8, patient.getWeight());
                pst.setInt (9, patient.getHeight());
                pst.setInt (10, patient.getBloodpressure());
                
                int numRowsAffected = pst.executeUpdate();
				
		if (numRowsAffected > 0) {
                    patientStatus = true;
            }
        }
    }
    catch (Exception ex) {
	if (conn != null) {
            try {
                
                pst.close();
                conn.close();
            }
            
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
        return patientStatus;
    }
}
