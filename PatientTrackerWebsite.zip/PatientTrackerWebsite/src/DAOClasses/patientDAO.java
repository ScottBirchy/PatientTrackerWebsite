package DAOClasses;

import modelClasses.patient;

public class patientDAO {
    
    boolean addPatient (patient patient);
    
}
