package DAOClasses;

import modelClasses.medication;

public class medicationDAO {
    
    boolean addMedication(medication medication);
    
}
