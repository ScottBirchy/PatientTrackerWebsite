package DAOClasses;

import modelClasses.insurance;

public class insuranceDAO {
    
    boolean addInsurance (insurance insurance);
    
}
