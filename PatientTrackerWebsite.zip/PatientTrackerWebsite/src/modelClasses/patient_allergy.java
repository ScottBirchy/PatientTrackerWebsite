package modelClasses;

public class patient_allergy {
    
    private int patient_patientid;
    private int allergy_allergyid;
	
	//setter and getters
	public int getPatient_patientid() {
		return patient_patientid;
	}
	public void setPatient_patientid(int patient_patientid) {
		this.patient_patientid = patient_patientid;
	}
	public int getAllergy_allergyid() {
		return allergy_allergyid;
	}
	public void setAllergy_allergyid(int allergy_allergyid) {
		this.allergy_allergyid = allergy_allergyid;
	}
    
}
