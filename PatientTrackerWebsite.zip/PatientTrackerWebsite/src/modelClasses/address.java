package modelClasses;

public class address {
    
    private int address_id; //primary key
    private int patient_id; //foreign key
    private String address;
    private String city;
    private int zip;
    private String state;
    
    public address (int address_id, int patient_id, String address, String city, int zip, String state) {
        super();
        this.address_id = address_id;
        this.patient_id = patient_id;
        this.address = address;
        this.city = city;
        this.zip = zip;
        this.state = state;
    }
    
    public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAddress_id() {
		return address_id;
	}
	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}
	public int getPatient_id() {
		return patient_id;
	}
	public void setPatient_id(int patient_id) {
		this.patient_id = patient_id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
    
}
