package modelClasses;

public class patient_insurance {
    
    private int patient_patiedid;	//FK
    private int insurance_insuranceid;  //FK
	
	//setter and getter
	public int getPatient_patiedid() {
		return patient_patiedid;
	}
	public void setPatient_patiedid(int patient_patiedid) {
		this.patient_patiedid = patient_patiedid;
	}
	public int getInsurance_insuranceid() {
		return insurance_insuranceid;
	}
	public void setInsurance_insuranceid(int insurance_insuranceid) {
		this.insurance_insuranceid = insurance_insuranceid;
	}
    
}
