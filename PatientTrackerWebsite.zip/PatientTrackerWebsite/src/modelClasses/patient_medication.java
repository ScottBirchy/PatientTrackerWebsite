package modelClasses;

import java.sql.Date;

public class patient_medication {
    
    private int patient_patientid;	//foreign key
    private int medication_medicationid; //FK
    private Date startdate;
	
	//setter and getter
	public int getPatient_patientid() {
		return patient_patientid;
	}
	public void setPatient_patientid(int patient_patientid) {
		this.patient_patientid = patient_patientid;
	}
	public int getMedication_medicationid() {
		return medication_medicationid;
	}
	public void setMedication_medicationid(int medication_medicationid) {
		this.medication_medicationid = medication_medicationid;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
}
