package modelClasses;

public class insurance {
    
    private int insuranceid;
    private String insurancename;
    
    public insurance (int insuranceid, String insurancename) {
        super();
        this.insuranceid = insuranceid;
        this.insurancename = insurancename;
    }
    
        public int getInsuranceid() {
		return insuranceid;
	}

	public void setInsuranceid(int insuranceid) {
		this.insuranceid = insuranceid;
	}

	public String getInsurancename() {
		return insurancename;
	}

	public void setInsurancename(String insurancename) {
		this.insurancename = insurancename;
	} 
}
