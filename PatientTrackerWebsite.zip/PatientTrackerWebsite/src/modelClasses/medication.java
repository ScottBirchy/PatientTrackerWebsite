package modelClasses;

public class medication {
    
    private int medicationid;
    private String medicationname;
    
    public medication (int medicationid, String medicationname) {
        super();
        this.medicationid = medicationid;
        this.medicationname = medicationname;
    }
	
	public int getMedicationid() {
		return medicationid;
	}
	//setters and getters
	public void setMedicationid(int medicationid) {
		this.medicationid = medicationid;
	}
	public String getMedicationname() {
		return medicationname;
	}
	public void setMedicationname(String medicationname) {
		this.medicationname = medicationname;
	}
}
