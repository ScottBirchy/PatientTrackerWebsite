package modelClasses;

public class allergy {
    
    private int allergyid;
    private String allergyname;
    
    public allergy (int allergyid, String allergyname) {
        super();
        this.allergyid = allergyid;
        this.allergyname = allergyname;
    }
	
	//setter and getter
	public int getAllergyid() {
		return allergyid;
	}
	public void setAllergyid(int allergyid) {
		this.allergyid = allergyid;
	}
	public String getAllergyname() {
		return allergyname;
	}
	public void setAllergyname(String allergyname) {
		this.allergyname = allergyname;
        }
}
